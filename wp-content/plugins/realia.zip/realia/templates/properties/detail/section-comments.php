<?php if ( comments_open() || get_comments_number() ) : ?>
    <?php comments_template( '', true ); ?>
<?php endif; ?>