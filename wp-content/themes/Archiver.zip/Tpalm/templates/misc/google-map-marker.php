<div class="marker"><div class="marker-inner">
	<?php the_post_thumbnail('thumbnail'); ?>
</div></div>
