module Bootstrap
  VERSION       = '3.3.3'
  BOOTSTRAP_SHA = 'bcf7dd38b5ab180256e2e4fb5da0369551b3f082'
end
